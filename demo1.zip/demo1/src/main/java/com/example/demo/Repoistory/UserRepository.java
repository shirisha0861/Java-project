package com.example.demo.Repoistory;

import com.example.demo.Entity.Userdetails;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<Userdetails, Integer> {
}
