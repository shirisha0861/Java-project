/*
 * package com.example.demo.Repoistory;
 * 
 * import com.example.demo.Entity.Cart_item; import
 * org.springframework.data.jpa.repository.JpaRepository; import
 * org.springframework.data.repository.CrudRepository;
 * 
 * public interface Cart_itemRepository extends CrudRepository<Cart_item, Long>
 * { static Iterable<Object> findByusername(String name) { return String name; }
 * }
 */
