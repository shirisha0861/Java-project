package com.example.demo.Entity;

import org.hibernate.annotations.RowId;

import javax.persistence.*;

@Entity
public class Register {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;
    public String name;
    public String password;
    public String confirm_password;
    public String email_id;
    public String mobile_no;

    public Register() {

    }

    /*
     * public Register(int id, String name, String password, String
     * confirm_password, String email_id, int mobile_no) { this.id = id; this.name =
     * name; this.password = password; this.confirm_password = confirm_password;
     * this.email_id = email_id; this.mobile_no = mobile_no; }
     */

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirm_password() {
        return confirm_password;
    }

    public void setConfirm_password(String confirm_password) {
        this.confirm_password = confirm_password;
    }

    public String getEmail_id() {
        return email_id;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public String getMobile_no() {
        return mobile_no;
    }

    public void setMobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }
}
